#Created a class called rectangle.
class Rectangle(object):
    def __init__(self, length, width):
        # the parameters length and width get absorbed into the Class Rectangle
        self.l = length
        self.w = width
    # Created a method called Perimeter using what is inherited from the class
    def Perimeter(self):
        # Created a variable called perimeter that finds the sum of twice the length and twice the width.
        perimeter = (2*self.l + 2*self.w)
        # When called the method will return the variable perimeter.
        return perimeter

    # Created a method called Area using what is inherited from the class.
    def Area(self):
        # Created a variable called area that finds the product of the length and the width.
        area = self.l * self.w
        # When called the method will return the variable area.
        return area
    # Created a method called display using what is inherited from the class.
    def display(self):
        # When called this method will return the length, the width, the perimeter, and the area.
        print('The length is ', self.l, '.')
        print('The width is ', self.w, '.')
        print('The perimeter of the rectangle is', Rectangle.Perimeter(self), '.')
        return 'The area of the rectangle is', Rectangle.Area(self)
# Created the child class called Parallelepiped whose parent class is rectangle
class Parallelepiped(Rectangle):
    # This class receives all the attributes of its parent class and adds the parameter height
    def __init__ (self, height):
        Rectangle.__init__(self,length, width)
        # created a variable called self.h that absorbs the parameter height
        self.h = height
    # Created a method called Volume
    def Volume(self):
        # created a variable called volume that took the three variables established and multiplied them
        volume = self.l * self.w * self.h
        # When called, the message and the variable volume are outputted
        return 'The volume of the parallelepiped is ', volume
# Set the variable value to 0
value = 0
# Created a loop that continues on unless the value doesn't equal 0
while value == 0:
    try:
        shape = str(input('Is your shape a Rectangle or Parallelepiped? : '))
        # Created a variable called length that takes a rational number input from the user
        length = float(input("Enter the length of a rectangle: "))
        # Created a variable called width that takes a rational number input from the user
        width = float(input("Enter the width of a rectangle: "))
        if shape == 'Rectangle':
            # Created a variable called rectangle that calls the method Rectangle with user-inputted parameters
            rectangle = Rectangle(length, width)
            # The variable calls the display method and this gets outputted to the user.
            print(rectangle.display())
        elif shape == 'Parallelepiped':
            # Created a variable called height that takes a rational number from the user
            height = float(input("Enter the height of the figure: "))
            # Created a variable called parallelepiped that calls the method Parallelepiped with user-inputted parameter height
            parallelepiped = Parallelepiped(height)
            # The variable calls the Volume method and this gets outputted to the user.
            print(parallelepiped.Volume())
        else:
            raise ValueError
        # Created a conditional statement where if the length or width is less than 1, the user has to try again
        if length <= 0 or width <= 0:
            raise ValueError
        else:
            # variable value gets increased by 1 if all conditions met, breaking the loop
            value += 1
    # Creates an exception if values aren't properly set a message gets outputted
    except ValueError:
        print("That is an invalid input.")