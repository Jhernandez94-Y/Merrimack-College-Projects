import HernandezDAL as dal
def Hello():
    try:
        print("Hello there! Welcome to the Merrimack River Cruises Database.")
        print("Please enter a number using the following menu:\n"
          "1- Get Passenger ID\n"
          "2 - Add Passenger\n"
          "3 - Get Vessel ID\n"
          "4 - Add Vessel\n"
          "5 - Get Total Revenue by Vessel\n"
          "6 - Get All Trips booked\n"
          "7 - Add a New Trip\n"
          "0 - Exit")
        data = int(input(""))
        return data
    except:
        print("That is not a valid input try again!")

def Hello2():
    try:
        print("Please enter a number using the following menu:\n"
          "1- Get Passenger ID\n"
          "2 - Add Passenger\n"
          "3 - Get Vessel ID\n"
          "4 - Add Vessel\n"
          "5 - Get Total Revenue by Vessel\n"
          "6 - Get All Trips booked\n"
          "7 - Add a New Trip\n"
          "0 - Exit")
        data = int(input(""))
        return data
    except:
        print("That is not a valid input try again!")
def getPassengerId():
    Pass = input("Enter the passenger name. ")
    PID = dal.Passengers_DAL.getPassenger(Pass)
    if PID == -1:
        print("That is not a valid ID, please try again.")
    print("Your Passenger ID is ", PID)
def AddPassenger():
    NPassN= input("Enter the passenger's name. ")
    NPassA = input("Enter the passenger's address. ")
    NPassP = input("Enter the passenger's phone number. ")
    AddPass = dal.Passengers_DAL.addPassenger(NPassN, NPassA, NPassP)
    return AddPass

def getVesselID():
    VesselName = input("Enter the name of the vessel. ")
    VID = dal.Vessels_DAL.getVesselID(VesselName)
    if VID == -1:
        print("That is not a valid vessel name, please try again.")
    return VID
def TotalRevenueByVessel():
    print("Here is the total revenue earned by each vessel: ")
    a = dal.Vessels_DAL.getTotalRevenueByVessel()
    for i in a:
        print("Vessel ", i, "has the following data: ")
def addVessel():
    NewVessel = input("Enter the name of the vessel. ")
    count = 1
    while(count == 1):
        try:
            CostPerHour = float(input("Enter the cost per hour of the vessel. "))
            Vessel = dal.Vessels_DAL.addVessel(NewVessel, CostPerHour)
            return Vessel
        except ValueError:
            print("That is not a valid input. Try again.")
def AllTrips():
    print("Please view the Merrimack River Cruises trips booked so far: ")
    t = dal.Trips_DAL.getTrips()
    for idx, trip in enumerate(t, start=1):
        date, length, vessel, passenger, addr, phone, total, cost = trip
        print(f"Trip {idx}: {date} | {vessel} | {passenger} | {length} hrs | {cost}")

def AddTrip():
    try:
        vName = input("Enter the name of the Vessel. ")
        pName = input("Enter the name of the passenger. ")
        Date = input("Enter the date of this trip. ")
        LoT = float(input("Enter the length of this trip in hours. "))
        NumOfPass = int(input("Enter the number of passengers. "))
    except:
        print("Not valid values, try again!")
    vesselID = dal.Vessels_DAL.getVesselID(vName)
    if vesselID == -1:
        print(f"Vessel '{vName}' not found. Adding it with default cost $150.")
        dal.Vessels_DAL.addVessel(vName, 150.00)
    passengerID = dal.Passengers_DAL.getPassenger(pName)
    if passengerID == -1:
        print(f"Passenger '{pName}' not found. Adding with placeholder info.")
        dal.Passengers_DAL.addPassenger(pName, "Unknown Address", "000-000-0000")
    Trip = dal.Trips_DAL.addTrip(vName, pName, Date, LoT, NumOfPass)
    return Trip

if __name__ == '__main__':
    start = Hello()
    count = 0

    while count == 0:
        if start == 1:
            getPassengerId()
            y = input("Would you like to do something else? (Type Yes or y) ")
            if y == "Yes" or y == "y":
                start = Hello2()
            else:
                quit()
        elif start == 2:
            print(AddPassenger())
            y = input("Would you like to do something else? (Type Yes or y) ")
            if y == "Yes" or y == "y":
                start = Hello2()
            else:
                quit()
        elif start == 3:
            print(getVesselID())
            y = input("Would you like to do something else? (Type Yes or y) ")
            if y == "Yes" or y == "y":
                start = Hello2()
            else:
                quit()
        elif start == 4:
            print(addVessel())
            y = input("Would you like to do something else? (Type Yes or y) ")
            if y == "Yes" or y == "y":
                start = Hello2()
            else:
                quit()
        elif start == 5:
            print(TotalRevenueByVessel())
            y = input("Would you like to do something else? (Type Yes or y) ")
            if y == "Yes" or y == "y":
                start = Hello2()
            else:
                quit()
        elif start == 6:
            print(AllTrips())
            y = input("Would you like to do something else? (Type Yes or y) ")
            if y == "Yes" or y == "y":
                start = Hello2()
            else:
                quit()
        elif start == 7:
            print(AddTrip())
            y = input("Would you like to do something else? (Type Yes or y)" )
            if y == "Yes" or y == "y":
                start = Hello2()
            else:
                quit()
        elif start == 0:
            print("Thank you for using the Merrimack River Cruises database. Goodbye!")
            quit()
        else:
            print("Please enter a valid input. ")
            start = Hello2()
