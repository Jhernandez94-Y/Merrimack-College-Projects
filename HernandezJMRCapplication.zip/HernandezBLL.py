import HernandezDAL as dal
def Hello():
    print("Hello there! Welcome to the Merrimack River Cruises Database.")

def getPassengerId(PassName):
    PID = dal.Passengers_DAL.getPassenger(PassName)
    if PID == -1:
        print("That is not a valid passenger name.")
    print("The Passenger's ID is ", PID)
def AddPassenger(NPassN, NPassA, NPassP):
    AddPass = dal.Passengers_DAL.addPassenger(NPassN, NPassA, NPassP)
    return AddPass

def getVesselID(VesselName):
    VID = dal.Vessels_DAL.getVesselID(VesselName)
    if VID == -1:
        print("That is not a valid vessel name, please try again.")
    else:
        print("The Vessel ID of ", VesselName, " is ", VID)
def TotalRevenueByVessel():
    print("Here is the total revenue earned by each vessel: ")
    a = dal.Vessels_DAL.getTotalRevenueByVessel()
    for i in a:
        print("Vessel ", i, "has the following data: ")
def addVessel(NewVessel):
    count = 1
    while(count == 1):
        try:
            CostPerHour = float(input("Enter the cost per hour of the vessel. "))
            Vessel = dal.Vessels_DAL.addVessel(NewVessel, CostPerHour)
            return Vessel
        except ValueError:
            print("That is not a valid input. Try again.")
def AllTrips():
    print("Please view the Merrimack River Cruises trips booked so far: ")
    t = dal.Trips_DAL.getTrips()
    for idx, trip in enumerate(t, start=1):
        date, length, vessel, passenger, addr, phone, total, cost = trip
        print(f"Trip {idx}: {date} | {vessel} | {passenger} | {length} hrs | {cost}")

def AddTrip(vName, pName, Date, LoT, NumOfPass):
        vesselID = dal.Vessels_DAL.getVesselID(vName)
        if vesselID == -1:
            print(f"Vessel '{vName}' not found. Adding it with default cost $150.")
            dal.Vessels_DAL.addVessel(vName, 150.00)

        # Check if passenger exists
        passengerID = dal.Passengers_DAL.getPassenger(pName)
        if passengerID == -1:
            print(f"Passenger '{pName}' not found. Adding with placeholder info.")
            dal.Passengers_DAL.addPassenger(pName, "Unknown Address", "000-000-0000")
        return dal.Trips_DAL.addTrip(vName, pName, Date, LoT, NumOfPass)

if __name__ == '__main__':
    start = Hello()
    TotalRevenueByVessel()
    getVesselID('The Warrior')
    getVesselID('The Snorior')
    print(AddTrip('The Warrior', 'John Smith', '2025-04-01 10:00:00', 2.5, 3))
    print(AddTrip('The Emperor', 'Darth Vader', '2024-05-04 05:04:00', 3, 2))

    AllTrips()
