import mysql.connector

config = {'host': 'localhost', 'user' : 'root', 'password': 'Yadira1214!', 'database': 'mrc'}

class DBConnection:
    mydb= mysql.connector.connect(**config)

class Vessels:
    def __init__(self, ID, Name, CostPerHour):
        self.ID = ID
        self.Name = Name
        self.CostPerHour = CostPerHour

    def __str__(self):
        return f'{self.ID} {self.Name} {self.CostPerHour}'
    def __repr__(self):
        return f'{self.ID} {self.Name} {self.CostPerHour}'

class Vessels_DAL:
    def getVesselID(VesselName):
        cnx = DBConnection.mydb
        cursor = cnx.cursor()
        func = "Select getVesselID(%s)"
        cursor.execute(func, [VesselName])
        result = cursor.fetchall()
        cursor.close()
        return result[0][0]
    def getTotalRevenueByVessel():
        cnx = DBConnection.mydb
        cursor = cnx.cursor()
        cursor.execute('Select * From TotalRevenueByVessel')
        result = cursor.fetchall()
        cursor.close()
        return result
    def addVessel(Name, CostPerHour='150.00'):
        cnx = DBConnection.mydb
        cursor = cnx.cursor()
        try:
            cursor.callproc('addVessel', [Name, CostPerHour])
            cnx.commit()
        except:
            return "There is an error."
        else:
            return "Vessel added successfully."
        cursor.close()

class Passengers:
    def __init__(self, ID, Name, Address, Phone):
        self.ID = ID
        self.Name = Name
        self.Address = Address
        self.Phone = Phone

    def __str__(self):
       return f'{self.ID} {self.Name} {self.Address} {self.Phone}'
    def __repr__(self):
        return f'{self.ID} {self.Name} {self.Address} {self.Phone}'

class Passengers_DAL:
    def getPassenger(PassengerID):
        cnx = DBConnection.mydb
        cursor = cnx.cursor()
        func = "Select getPassengerID(%s)"
        cursor.execute(func, [PassengerID])
        result = cursor.fetchall()
        cursor.close()
        return result[0][0]
    def addPassenger(Name, Address, Phone):
        cnx = DBConnection.mydb
        cursor = cnx.cursor()
        try:
            cursor.callproc('addPassenger', [Name, Address, Phone])
            cnx.commit()
        except:
            return "There is an error."
        else:
            return "Passenger added successfully."
        cursor.close()

class Trips:
        def __init__(self, vID, pID, dateAndTime, lengthOfTrip, TotalPassengers):
            self.vid = vID
            self.pid = pID
            self.dateAndTime = dateAndTime
            self.lengthOfTrip = lengthOfTrip
            self.TotalPassengers = TotalPassengers

        def __str__(self):
            return f'{self.vid} {self.pid} {self.dateAndTime} {self.lengthOfTrip}'

        def __repr__(self):
            return f'{self.vid} {self.pid} {self.dateAndTime} {self.lengthOfTrip}'

class Trips_DAL:
    def getTrips():
        cnx = DBConnection.mydb
        cursor = cnx.cursor()
        cursor.execute('Select * From AllTrips')
        result = cursor.fetchall()
        cursor.close()
        return result

    def addTrip(veName, paName, Date, length, totalPassengers):
        cnx = DBConnection.mydb
        cursor = cnx.cursor()
        try:
            cursor.callproc('addTrip', [veName, paName, Date, length, totalPassengers])
            cnx.commit()
        except:
            return "There is an error."
        else:
            return "Trip added successfully."
        cursor.close()