def squaresSum(n):
    # if parameter n is equal to 1, return the value 1 due to 1 squared equaling 1
    if n == 1:
        return 1
    elif n == 0:
        return 0
    elif n < 0:
        quit()
    #Recursion occurs based on the integer given. The value returned is added to the current iteration of the value squared.
    else:
        return squaresSum(n - 1) + n * n
n1 = 12
n2 = 20
a = squaresSum(n1)
b = squaresSum(n2)
print("Sum of squares for ", n1," is", a)
print("Sum of squares for ", n2," is", b)