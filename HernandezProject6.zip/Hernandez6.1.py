import math

def binaryDigits(n):
    #if the parameter input is equal to 1, the program returns 1 as that's how many digits are in the value
    if n == 1:
        return 1
    elif n == 0:
        return 0
    elif n < 0:
        quit()
    #Recursion occurs when n > 1. When this happens add 1 to the function binary digits, where the parameter n is divided by 2
    else:
        return 1 + binaryDigits(math.floor(n / 2))

# Test cases
n1 = 256
n2 = 750
a = binaryDigits(n1)
b = binaryDigits(n2)
print("The number of binary digits for",n1, " is", a)
print("The number of binary digits for",n2, " is", b)