import random


def generate_array(size):
    half_size = size // 2
    array = [1] * half_size + [0] * half_size
    random.shuffle(array)
    return array


def monte_carlo_search(arr, k):
    for attempt in range(1, k + 1):
        index = random.randint(0, len(arr) - 1)
        # Check if it's a 1
        if arr[index] == 1:
            # Return the index and the number of tries
            return index, attempt
    # If not found after k attempts
    return None, k


if __name__ == "__main__":
    size = 10000
    k = 10
    array = generate_array(size)

    # Perform the Monte Carlo search
    found_index, tries = monte_carlo_search(array, k)

    if found_index is not None:
        print(f"Found a 1 at index: {found_index} after {tries} tries.")
    else:
        print(f"Did not find a 1 after {k} attempts.")