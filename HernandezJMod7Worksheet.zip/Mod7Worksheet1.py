import random

def generate_array(size):
    half_size = size // 2
    array = [1] * half_size + [0] * half_size
    random.shuffle(array)
    return array

def randomized_las_vegas_search(arr):
    while True:
        index = random.randint(0, len(arr) - 1)
        if arr[index] == 1:
            return index
if __name__ == "__main__":
    size = 10000
    array = generate_array(size)

    # Perform the randomized Las Vegas search
    found_index = randomized_las_vegas_search(array)
    print(f"Found a 1 at index: {found_index}")