import math

def calculate_area_of_rectangle(length, width):
    """
    Summary:
    Mutliplies two values, rounds to hundredths place, and returns a result

    Parameters:
    length (float): first number
    width (float): second number

    Returns:
    float: Product of two values that is rounded to hundredths place

    Examples
    --------
    >>> calculate_area_of_rectangle(3, 4)
    12.0
    >>> calculate_area_of_rectangle(3.25, 4)
    13.0
    >>> calculate_area_of_rectangle(6.7, 35.4)
    237.18
    >>> calculate_area_of_rectangle(5.872, 4.23)
    24
    >>> calculate_area_of_rectangle(5.872, 4.23)
    24.84
    """
    area = length * width
    area = math.ceil(area*100)/100
    return area

value = 0
while value == 0:
    try:
        # Takes 2 float values from users
        a = float(input("What is the length of your rectangle? "))
        b = float(input("What is the width of your rectangle? "))
        # If inputted values are less than or equal to 0, raise Error
        if a <= 0 or b <= 0:
            raise ValueError
        # ends loop if else statement activated
        else:
            value = 1
    # Raise exception for values
    except ValueError:
        print("That is not a valid input. Try again.")
if __name__ == '__main__':
    import doctest
    doctest.testmod()
    c = calculate_area_of_rectangle(a,b)
    print(f"The area of your rectangle is {c}")
