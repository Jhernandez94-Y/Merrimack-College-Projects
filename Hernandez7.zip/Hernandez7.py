#Imported modules random and timeit
import random
import timeit

#Created a function that takes a parameter (preferably a list) and sorts it using bubble method
def bubblesort(list):
    # Swap elements to arrange in order
    for iter_num in range(len(list)-1,0,-1):
        for idx in range(iter_num):
            if list[idx]>list[idx+1]:
                temp = list[idx]
                list[idx] = list[idx+1]
                list[idx+1] = temp
    # Returns the sorted list as a value
    return list
# Created an object called listed
listed = []
# Created for loop that continues onward to a value of 100
for i in range(1000):
    # created a variable a that takes in a random value between 1 and 100000
    a = random.randint(1, 100000)
    # Adds the value of a into variable called listed
    listed.append(a)
# Created another variable that contains the same listed values as the variable listed
list2 = listed

# Created a variable called execution time that takes the amount of time it took to use bubblesort function and stores it.
execution_time = timeit.timeit(lambda: bubblesort(listed), number = 1)
# Outputs time takes to sort list use bubble sort and then outputs the actual list of elements
print(f"Bubble Sort execution time: {execution_time} seconds")
print("Sorted List: ", bubblesort(listed))

#Created a function that takes a parameter (preferably a list) and sorts it using insertion sort method
def insertion_sort(InputList):
    for i in range(1, len(InputList)):
        j = i-1
        nxt_element = InputList[i]
        nxt_index = i
# Compares the current element with next one
        while (InputList[j] > nxt_element) and (j >= 0):
            InputList[j+1] = InputList[j]
            j=j-1
        InputList[j+1] = nxt_element
    return InputList
# Created a variable called execution time2 that takes the amount of time it took to use insertion sort function and stores it.
execution_time2 = timeit.timeit(lambda: insertion_sort(list2), number = 1)
# Outputs time takes to sort list use insertion sort and then outputs the actual list of elements
print(f"Insertion Sort execution time: {execution_time2} seconds")
print("Sorted List: ", insertion_sort(list2))