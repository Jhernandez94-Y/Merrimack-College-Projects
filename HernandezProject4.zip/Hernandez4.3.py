# Created function called matrix_product that takes 3 inputs
def matrix_product(n, A, B):
    # Initialize a nxn matrix C to store the product of matrix A & B
    C = [[0] * n for _ in range(n)]
    # Created multiple for loops to properly multiply between values in matrices
    for i in range(n):
        for j in range(n):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]
                C[i][j] = round(C[i][j], 2)
    return C
# Function to print out the matrix to the user
def print_matrix(matrix):
    for row in matrix:
        print(row)
def main():
    n = 2
    A = [[2, 7],
         [3, 5]]
    B = [[8, -4],
         [6, 6]]
    result = matrix_product(n, A, B)
    print_matrix(result)
if __name__ == '__main__':
    main()