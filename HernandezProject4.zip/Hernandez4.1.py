# Created function that returns values that are divisible by an integer from an array
def divisible(integer, array):
    # Created list to store values that are divisible
    list = []
    # Created variable that increments based on values that are divisble from array
    count = 0
    for i in array:
        if i % integer == 0:
            list.append(i)
            count += 1
    return list, count

# Main function of program
def main():
    a = [18, 54, 76, 81, 36, 48, 99]
    inte = 9
    b = divisible(inte, a)
    print("The number of entries that are divisible by", inte, "is ", b[1])

if __name__ == '__main__':
    main()