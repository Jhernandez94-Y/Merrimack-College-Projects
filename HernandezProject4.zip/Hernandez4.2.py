# Function that finds the smallest gap between values in an array
def smallest_gap(A):
    # Variable n stores size of array. If array size less than 2, returns 0
    n = len(A)
    if n < 2:
        return 0
    # created variable that stores an infinite value
    min_gap = float('inf')
    for i in range(n):
        for j in range(i + 1, n):
            # Created variable that stores the difference of the absolute value of 2 #s in array
            gap = abs(A[i] - A[j])
            # If variable gap is less than the min_gap, gap gets stored as new min_gap
            if gap < min_gap:
                min_gap = gap

    return min_gap
# Main function that initiates program and where array is created
def main():
    A =  [50, 120, 250, 100, 20, 300, 200]
    print("The smallest gap found in this array is", smallest_gap(A))

if __name__ == '__main__':
    main()