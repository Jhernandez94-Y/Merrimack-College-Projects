from Hernandez3 import *
import unittest
class TestMethods(unittest.TestCase):
    def test_setupBoard(self):
        setupBoard.assertEqual(num_of_ships, 5)
    def test_checkHitOrMiss(self):
        test1 = CheckHitOrMiss([0, 1])
        test1.assertEqual(myBoard[value1][value2], "X", "Hit")
        test2 = CheckHitOrMiss([0, 1])
        test2.assertEqual(myBoard[value1][value2], "O", "Miss")
    def test_isGameOver(self):
        isGameOver.assertTrue(True)
        isGameOver.assertFalse(False)