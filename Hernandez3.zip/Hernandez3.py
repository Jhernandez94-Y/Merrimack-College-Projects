import random
# Outputs message to user explaining the rules.
print("""
-------BATTLESHIPS-------
Pre-reqs: Loops, Strings, Arrays, 2D Arrays, Global Variables, Methods
How it will work:
1. A 10x10 grid will have 5 ships randomly placed about
2. You can choose a row and column to indicate where to shoot
3. For every shot that hits or misses it will show up in the grid
4. If all ships are shot, game over
Legend:
1. "." = water
2. "S" = ship position
3. "O" = water that was shot with bullet, a miss because it hit no ship
4. "X" = ship sunk!
""")
# Created variable lives that controls number of tries user gets
lives = 25
# Created variable num_of_ships that represents the number of boats still present on the board
num_of_ships = 5
# Variable counter set to control while loop
counter = 0
# Created a grid called myBoard, where the game BattleShip will be played. Both first column and second column are
# different values due their lack of usage in the game. They work as a key for the user to locate the ships in the game.
myBoard = [[" ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
               ["0", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["1", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["2", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["3", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["4", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["5", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["6", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["7", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["8", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["9", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."]]
# Function created to give ship locations.
# created 5 ships to be used in the game
ship1, ship2, ship3, ship4, ship5 = 0, 0, 0, 0, 0
def redoShips():
 # received the values for counter and the ships
 global counter, ship1, ship2, ship3, ship4, ship5
 # gave the variables ships random values between 1 and 9
 ship1 = random.randint(1, 10), random.randint(1, 10)
 ship2 = random.randint(1, 10), random.randint(1, 10)
 ship3 = random.randint(1, 10), random.randint(1, 10)
 ship4 = random.randint(1, 10), random.randint(1, 10)
 ship5 = random.randint(1, 10), random.randint(1, 10)
 # set loop with counter
 while counter == 0:
    if ship1 == ship2 or ship1 == ship3 or ship1 == ship4 or ship1 == ship5:
        ship1 = random.randint(1, 10), random.randint(1, 10)
    elif ship2 == ship3 or ship2 == ship4 or ship2 == ship5:
        ship2 = random.randint(1, 10), random.randint(1, 10)
    elif ship3 == ship4 or ship3 == ship5:
        ship3 = random.randint(1, 10), random.randint(1, 10)
    elif ship4 == ship5:
        ship4 = random.randint(1, 10), random.randint(1, 10)
    else:
        # counter set to one once all ships contain different coordinates
        counter = 1
# This function serves as the start for the game
def setupBoard():
    global myBoard, ship1, ship2, ship3, ship4, ship5, num_of_ships
    # Created a conditional statement that only activates if the variable num_of_ships is 5
    if num_of_ships == 5:
        # All the different spaces on the board that match the coordinates of the ships get changed to S
        myBoard[ship1[0]][ship1[1]] = "S"
        myBoard[ship2[0]][ship2[1]] = "S"
        myBoard[ship3[0]][ship3[1]] = "S"
        myBoard[ship4[0]][ship4[1]] = "S"
        myBoard[ship5[0]][ship5[1]] = "S"
    # created variable value to use as counter for while loop
    value = 0
    # output the board with
    for i in myBoard:
        print(i)
    while value == 0:
        try:
            # Created a variable called UserRow that takes an integer input from the user between 1-9
            UserRow = int(input("Enter row between 1-9: "))
            # Created a variable called UserCol that takes an integer input from the user between 1-9
            UserCol = int(input("Enter column between 1-9: "))

            # Created conditional statement, if user selected values greater than 9 or less than 1 they are forced to reselect values.
            if UserRow < 0 or UserRow > 10 or UserCol < 0 or UserCol > 10:
                print("The numbers must be between 0 and 9.")
            else:
                value = 1
            # Created an exception, if user enters a value other than an integer they will receive a message and have to try
            # again
        except ValueError:
            print("You must enter a number.")
    # added 1 to user input to provide proper index values with method checkHitOrMiss
    UserRow = UserRow + 1
    UserCol = UserCol + 1
    checkHitOrMiss([myBoard, UserRow, UserCol])

# Method checkHitOrMiss parameter represents a list that contains 3 objects
def checkHitOrMiss(value1):
    # called global variables lives and count
        global lives, num_of_ships, ship1, ship2, ship3, ship4, ship5
    # received values from parameter (which was a list)  and created variables to take each values from the list
        myBoard = value1[0]
        value2 = value1[2]
        value1 = value1[1]
    # Created loops using global variables lives and count.
        while lives > 0:
          while num_of_ships > 0:
        # Created conditional statements, if user input matches any of the coordinates for ships 1 through 5 outputs message Hit
            if (value1, value2) == ship1 or (value1, value2) == ship2 or (value1, value2) == ship3 or (value1, value2) == ship4 or (value1, value2) == ship5:
            # created conditional statment, if user tried again to select the same row and column, they will receive
            # a message and be prompted to try again.
                if myBoard[value1][value2] == "X":
                    print("You chose that already!")
                    setupBoard()
            # If user chooses a new row and column that matches with one of the locations of the ships, outputs message
                elif myBoard[value1][value2] == "S":
                    print("Hit")
                # If True, the user selected coordinates replaces the location on the board with an X, signifying a hit.
                    myBoard[value1][value2] = "X"
                # User gets an additional life for hitting the ship successfully
                    lives += 1
                # User gets a message stating how many lives they have left.
                    print("Lives left: ", lives)
                    # Variable count gets decreased by 1.
                    num_of_ships -= 1
                    # set conditional statement if num_of_ships is equivalent to zero then activate isGameOver function with boolean True
                    if num_of_ships == 0:
                        isGameOver(True)
                    else:
                        setupBoard()

            elif (value1, value2) != ship1 or (value1, value2) != ship2 or (value1, value2) != ship3 or (value1, value2) != ship4 or (value1, value2) != ship5:
                # created conditional statement, if user tried again to select the same row and column, they will
                # receive a message and be prompted to try again.
                if myBoard[value1][value2] == "O":
                    print("You chose that already!")
                    setupBoard()
                # If user chooses a new row and column that matches with one of the locations of the ships, output message
                elif myBoard[value1][value2] == ".":
                    print("MISS")
                # The missed coordinates replace the location on the board with an O
                    myBoard[value1][value2] = "O"
                # The user loses a life, bringing them closer to a game over
                    lives -= 1
                # The game then outputs a string telling the user how many lives they have left
                    print("lives left: ", lives)
                    # if lives equals 0 move to next function and set parameter to false
                    # set conditional statement if lives is equivalent to zero then activate isGameOver function with Boolean False
                    if lives == 0:
                        isGameOver(False)
                    else:
                        setupBoard()

def isGameOver(v1):
    # received global variables lives and count
    global myBoard, counter, lives, num_of_ships
    print("The ship locations were", ship1, ship2, ship3, ship4, ship5)
    # Reset game board
    myBoard = [[" ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
               ["0", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["1", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["2", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["3", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["4", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["5", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["6", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["7", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["8", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."],
               ["9", ".", ".", ".", ".", ".", ".", ".", ".", ".", "."]]
    counter = 0
    # Set conditional statement if count is equal to zero, user receives message
    if v1 == True:
        print("You Win! YOU ARE AMAZING!")
    # User then gets asked if they would like to play again.
        play_again = input("Would you like to play again? (y for yes or n for no) ")
    # If user enters the y or yes they will get to restart the game. Function gets restarted
        if play_again == "y" or play_again == "yes":
            #Global Variables are reset to initial values
            lives = 25
            num_of_ships = 5
            main()
    # If the user enters the string 'n' they will get a message and program will end.
        elif play_again == "n" or play_again == "no":
            print("Thanks for playing!")
            quit()
    # If the user enters anything other than y or n the program will end
        else:
            print("Not a valid input. Goodbye!")
            quit()
    else:
       print("Game Over")
       # User then gets prompt to try again.
       try_again = input("Would you like to try again? y for yes or n for no ")
       # If user enters y or yes they will get to restart the game.
       if try_again == "y" or try_again == "yes":
           # Global Variables are reset to initial values
           lives = 25
           num_of_ships = 5
           main()
       # If the user enters the string 'n' they will get a message and program will end.
       elif try_again == "n" or try_again == "no":
            print("Good luck next time!")
            quit()
            # If the user enters another string then outputs a message and program ends
       else:
            print("Invalid Input. Goodbye!")
            quit()
# Function that starts the program
def main():
    # variable userInput is set to the output of the function setupBoard with parameter of grid (myBoard)
    redoShips()
    userInput = setupBoard()
    checkHitOrMiss(userInput)
    # Calling function main
main()
