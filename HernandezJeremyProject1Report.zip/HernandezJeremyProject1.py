import random
import cProfile
# Created function that sorts using insertion algorithm
def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key

def main():
    # Created arrays for each iteration
    Array = []
    ArrayTwo = []
    ArrayThree = []
    ArrayFour = []
    ArrayFive = []
    ArraySix = []
    ArraySeven = []
    ArrayEight = []
    ArrayNine = []
    ArrayTen = []
    # Created for loop to generate for vector with 1000 random values
    for i in range(1000):
        a = random.randint(1, 1000)
        Array.append(a)
    # Outputted Array beforehand
    print("Array before sort: ", Array)
    insertion_sort(Array)
    # Outputted Array after the sort
    print("Array after sort: ", Array)
    # Similar to above but following arrays increase by 1000 in terms of size.
    for i in range(2000):
        a = random.randint(1, 2000)
        ArrayTwo.append(a)
    print("Array before sort: ", ArrayTwo)
    insertion_sort(ArrayTwo)
    print("Array after sort: ", ArrayTwo)
    for i in range(3000):
        a = random.randint(1, 3000)
        ArrayThree.append(a)
    print("Array before sort: ", ArrayThree)
    insertion_sort(ArrayThree)
    print("Array after sort: ", ArrayThree)
    for i in range(4000):
        a = random.randint(1, 4000)
        ArrayFour.append(a)
    print("Array before sort: ", ArrayFour)
    insertion_sort(ArrayFour)
    print("Array after sort: ", ArrayFour)
    for i in range(5000):
        a = random.randint(1, 5000)
        ArrayFive.append(a)
    print("Array before sort: ", ArrayFive)
    insertion_sort(ArrayFive)
    print("Array after sort: ", ArrayFive)
    for i in range(6000):
        a = random.randint(1, 6000)
        ArraySix.append(a)
    print("Array before sort: ", ArraySix)
    insertion_sort(ArraySix)
    print("Array after sort: ", ArraySix)
    for i in range(7000):
        a = random.randint(1, 7000)
        ArraySeven.append(a)
    print("Array before sort: ", ArraySeven)
    insertion_sort(ArraySeven)
    print("Array after sort: ", ArraySeven)
    for i in range(8000):
        a = random.randint(1, 8000)
        ArrayEight.append(a)
    print("Array before sort: ", ArrayEight)
    insertion_sort(ArrayEight)
    print("Array after sort: ", ArrayEight)
    for i in range(9000):
        a = random.randint(1, 9000)
        ArrayNine.append(a)
    print("Array before sort: ", ArrayNine)
    insertion_sort(ArrayNine)
    print("Array after sort: ", ArrayNine)
    for i in range(10000):
        a = random.randint(1, 10000)
        ArrayTen.append(a)
    print("Array before sort: ", ArrayTen)
    insertion_sort(ArrayTen)
    print("Array after sort: ", ArrayTen)
if __name__ == "__main__":
    cProfile.run('main()')
