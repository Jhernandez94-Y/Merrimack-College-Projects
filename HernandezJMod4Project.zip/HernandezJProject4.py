def knapsack(item, cap):
    rwv = []         # item, volume, value, index
    for i in range(len(item)):
        rwv.append([item[i][0],item[i][1],item[i][2],i])
    rwv.sort(reverse=True)    # sort from high to low rate
    ans = []                     # the list of added items
    tvol = 0                                  # total Volume
    found = True
    while (found):        # until no fitting item is found
        found = False
        for t in rwv:              # search an item to add
            if (t[1] + tvol) <= cap:      # if the item fits
                ans.append(t[3])                  # add it
                tvol += t[1]
                found = True
                break
    return ans           # returns the list of added items

def main():
    items = []
    # Created while loop to account for user inputting wrong filename
    # Used try statement to account for errors
    while(True):
        try:
            # stores user input for filename
            fileName = input("Please enter your filename: ")
            #opens file
            with open(fileName, "r") as infile:
                for line in infile:
                    parts = line.strip().split(',')
                    # Conditional statement, if file does not contain 5 total parts, values not stored in array
                    if len(parts) == 5:
                        name, value, height, width, depth = parts
                        value = int(value)
                        height = int(height)
                        width = int(width)
                        depth = int(depth)
                        volume = height * width * depth
                        #adds name of item, volume, and value to array
                        items.append((name, volume, value))
                    else:
                        FileNotFoundError
            # breaks out of while loop if conditions met
            break
        except FileNotFoundError:
            print("File could not be opened.")
# Asks user to input volume.
    max_volume = int(input("Enter the maximum volume of the knapsack (in cubic inches): "))
    answer = knapsack(items, max_volume)
    itemCount, tv, tvol = 0, 0, 0
    for a in answer:
            print("Item- ", items[a][0], "Value:", items[a][2], "Volume:", items[a][1])
            # Keeps account of items, total
            itemCount += 1
            tvol += items[a][1]
            tv += items[a][2]
    print("The suggested items are:", itemCount, items[0][0], " with a value of", tv, "and a total Volume of", tvol)
    print("There were", max_volume-tvol,"cubic inches unused.")

main()

